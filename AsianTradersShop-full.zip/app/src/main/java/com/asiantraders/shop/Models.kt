package com.asiantraders.shop

data class Product(
    val id: String = "", val name: String = "", val description: String = "",
    val imageUrl: String = "", val createdAt: Long = 0
)
data class OrderItem(val productId: String = "", val name: String = "", val qty: Int = 1)
data class Order(
    val id: String = "", val customerId: String = "", val customerName: String = "",
    val phone: String = "", val items: List<OrderItem> = emptyList(), val photoUrl: String = "",
    val note: String = "", val status: String = "PENDING", val createdAt: Long = 0
)
data class AppUser(
    val uid: String = "", val name: String = "", val phone: String = "",
    val role: String = "customer", val fcmToken: String = ""
)
val AppUser.isOwner get() = role == "owner"
