package com.asiantraders.shop

import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object Repo {
    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private val st get() = FirebaseStorage.getInstance()

    /** Customers log in with phone number; owner can use a real email. */
    fun emailFor(login: String) = if ("@" in login) login.trim() else "${login.trim()}@asiantraders.shop"

    suspend fun login(login: String, pass: String) { auth.signInWithEmailAndPassword(emailFor(login), pass).await() }
    fun logout() = auth.signOut()

    suspend fun profile(): AppUser? {
        val u = auth.currentUser ?: return null
        val d = db.collection("users").document(u.uid).get().await()
        return d.toObject(AppUser::class.java)?.copy(uid = u.uid)
    }

    suspend fun registerToken(u: AppUser) {
        db.collection("users").document(u.uid).update("fcmToken", FirebaseMessaging.getInstance().token.await()).await()
        if (u.isOwner) FirebaseMessaging.getInstance().subscribeToTopic("owner").await()
    }

    fun products(): Flow<List<Product>> = callbackFlow {
        val l = db.collection("products").addSnapshotListener { s, _ ->
            if (s != null) trySend(s.documents.mapNotNull { d -> d.toObject(Product::class.java)?.copy(id = d.id) }
                .sortedBy { it.name.lowercase() })
        }
        awaitClose { l.remove() }
    }

    fun orders(u: AppUser): Flow<List<Order>> = callbackFlow {
        val q = if (u.isOwner) db.collection("orders") else db.collection("orders").whereEqualTo("customerId", u.uid)
        val l = q.addSnapshotListener { s, _ ->
            if (s != null) trySend(s.documents.mapNotNull { d -> d.toObject(Order::class.java)?.copy(id = d.id) }
                .sortedByDescending { it.createdAt })
        }
        awaitClose { l.remove() }
    }

    fun customers(): Flow<List<AppUser>> = callbackFlow {
        val l = db.collection("users").whereEqualTo("role", "customer").addSnapshotListener { s, _ ->
            if (s != null) trySend(s.documents.mapNotNull { d -> d.toObject(AppUser::class.java)?.copy(uid = d.id) }
                .sortedBy { it.name.lowercase() })
        }
        awaitClose { l.remove() }
    }

    suspend fun saveProduct(ctx: Context, p: Product, img: Uri?) {
        val ref = db.collection("products").document(p.id.ifEmpty { db.collection("products").document().id })
        var url = p.imageUrl
        if (img != null) {
            val r = st.reference.child("products/${ref.id}.jpg")
            r.putBytes(compress(ctx, img)).await()
            url = r.downloadUrl.await().toString()
        }
        ref.set(p.copy(id = "", imageUrl = url, createdAt = if (p.createdAt == 0L) System.currentTimeMillis() else p.createdAt)).await()
    }

    suspend fun deleteProduct(p: Product) {
        db.collection("products").document(p.id).delete().await()
        runCatching { st.reference.child("products/${p.id}.jpg").delete().await() }
    }

    /** Creates the login on a secondary Firebase app so the owner stays signed in. */
    suspend fun createCustomer(ctx: Context, name: String, phone: String, password: String) {
        val opts = FirebaseApp.getInstance().options
        val app = runCatching { FirebaseApp.getInstance("helper") }.getOrElse { FirebaseApp.initializeApp(ctx, opts, "helper") }
        val a2 = FirebaseAuth.getInstance(app)
        val uid = a2.createUserWithEmailAndPassword(emailFor(phone), password).await().user!!.uid
        a2.signOut()
        db.collection("users").document(uid).set(AppUser(name = name, phone = phone, role = "customer")).await()
    }

    suspend fun deleteCustomer(uid: String) { db.collection("users").document(uid).delete().await() }

    suspend fun placeOrder(ctx: Context, u: AppUser, items: List<OrderItem>, note: String, photo: Uri?) {
        val ref = db.collection("orders").document()
        var url = ""
        if (photo != null) {
            val r = st.reference.child("orders/${u.uid}/${ref.id}.jpg")
            r.putBytes(compress(ctx, photo)).await()
            url = r.downloadUrl.await().toString()
        }
        ref.set(Order(customerId = u.uid, customerName = u.name, phone = u.phone, items = items,
            photoUrl = url, note = note, status = "PENDING", createdAt = System.currentTimeMillis())).await()
    }

    suspend fun setStatus(id: String, status: String) { db.collection("orders").document(id).update("status", status).await() }

    private fun compress(ctx: Context, uri: Uri, maxSide: Int = 1280): ByteArray {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (max(bounds.outWidth, bounds.outHeight) / s > maxSide * 2) s *= 2
        val bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }!!
        val rot = cr.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        }
        val sc = min(1f, maxSide.toFloat() / max(bmp.width, bmp.height))
        val m = Matrix().apply { postRotate(rot); postScale(sc, sc) }
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        return ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
    }
}
