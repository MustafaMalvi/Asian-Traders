package com.asiantraders.shop

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

const val CHANNEL = "orders"

fun ensureChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26)
        c.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CHANNEL, "Orders", NotificationManager.IMPORTANCE_HIGH))
}

class ShopMessaging : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseFirestore.getInstance().collection("users").document(uid).update("fcmToken", token)
    }

    // Foreground messages; background ones are shown by the system.
    override fun onMessageReceived(m: RemoteMessage) {
        val n = m.notification ?: return
        ensureChannel(this)
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(n.title).setContentText(n.body).setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
        try { NotificationManagerCompat.from(this).notify(System.currentTimeMillis().toInt(), b.build()) } catch (e: SecurityException) {}
    }
}
