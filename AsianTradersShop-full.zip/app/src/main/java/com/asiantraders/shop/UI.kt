package com.asiantraders.shop

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(t: Long) = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(t))
private val ImageOnly = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)

@Composable
fun App(vm: AppVM) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { vm.toast.collect { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() } }
    val ready by vm.ready.collectAsStateWithLifecycle()
    val user by vm.user.collectAsStateWithLifecycle()
    val u = user
    when {
        !ready -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        u == null -> LoginScreen(vm)
        else -> Home(vm, u)
    }
}

@Composable
fun LoginScreen(vm: AppVM) {
    var id by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    val busy by vm.busy.collectAsStateWithLifecycle()
    val c = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.primary, Color(0xFF2E5A9E)))).systemBarsPadding()) {
        Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Storefront, null, tint = c.secondary, modifier = Modifier.size(64.dp))
            Text("Asian Traders", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Hardware & General Store", color = Color.White.copy(alpha = .8f))
            Spacer(Modifier.height(28.dp))
            Card(shape = RoundedCornerShape(28.dp)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Sign in", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(id, { id = it }, label = { Text("Phone number") }, singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Phone, null) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pw, { pw = it }, label = { Text("Password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        leadingIcon = { Icon(Icons.Default.Lock, null) }, modifier = Modifier.fillMaxWidth())
                    Button({ vm.login(id, pw) }, enabled = !busy && id.isNotBlank() && pw.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(if (busy) "Signing in…" else "Sign in") }
                    Text("New accounts are created by the shop owner.", style = MaterialTheme.typography.bodySmall,
                        color = c.onSurfaceVariant, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                }
            }
        }
    }
}

private data class Tab(val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(vm: AppVM, u: AppUser) {
    val owner = u.isOwner
    val tabs = if (owner) listOf(Tab("Products", Icons.Default.Inventory2), Tab("Orders", Icons.Default.Receipt), Tab("Customers", Icons.Default.People))
    else listOf(Tab("Shop", Icons.Default.Storefront), Tab("My List", Icons.Default.ShoppingCart), Tab("Orders", Icons.Default.Receipt))
    var sel by rememberSaveable { mutableIntStateOf(0) }
    val cartCount = vm.cart.values.sum()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("Asian Traders", fontWeight = FontWeight.Bold)
                    Text(if (owner) "Owner" else u.name, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } },
                actions = { IconButton({ vm.logout() }) { Icon(Icons.AutoMirrored.Filled.Logout, "Logout") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(selected = sel == i, onClick = { sel = i }, label = { Text(t.label) }, icon = {
                        if (!owner && i == 1 && cartCount > 0) BadgedBox(badge = { Badge { Text("$cartCount") } }) { Icon(t.icon, null) }
                        else Icon(t.icon, null)
                    })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (sel) {
                0 -> Catalog(vm, owner)
                1 -> if (owner) OrdersScreen(vm, true) else CartScreen(vm)
                else -> if (owner) CustomersScreen(vm) else OrdersScreen(vm, false)
            }
        }
    }
}

@Composable
fun Empty(t: String) = Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
    Text(t, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
}

/* ---------------------------- Catalog ---------------------------- */

@Composable
fun Catalog(vm: AppVM, owner: Boolean) {
    val products by vm.products.collectAsStateWithLifecycle()
    var q by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<Product?>(null) }
    var deleting by remember { mutableStateOf<Product?>(null) }
    val list = remember(products, q) { products.filter { Search.matches(it, q) } }
    Box(Modifier.fillMaxSize()) {
        Column {
            OutlinedTextField(q, { q = it }, singleLine = true, shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Search products, e.g. ss 19x6") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Default.Close, null) } },
                modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp, 16.dp, 4.dp))
            if (list.isEmpty()) Empty(if (products.isEmpty()) "No products yet." else "No products match “$q”.")
            else LazyVerticalGrid(GridCells.Adaptive(160.dp), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(list, key = { it.id }) { p ->
                    ProductCard(p, owner, vm.cart[p.id] ?: 0, { vm.setQty(p.id, it) }, { editing = p }, { deleting = p })
                }
            }
        }
        if (owner) ExtendedFloatingActionButton({ editing = Product() }, Modifier.align(Alignment.BottomEnd).padding(20.dp),
            icon = { Icon(Icons.Default.Add, null) }, text = { Text("Add product") })
    }
    editing?.let { ProductDialog(it, vm) { editing = null } }
    deleting?.let { p ->
        AlertDialog(onDismissRequest = { deleting = null }, title = { Text("Delete product?") },
            text = { Text("“${p.name}” will be removed from the catalog.") },
            confirmButton = { TextButton({ vm.deleteProduct(p); deleting = null }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } })
    }
}

@Composable
fun Stepper(q: Int, onChange: (Int) -> Unit) = Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
    FilledTonalIconButton({ onChange(q - 1) }, Modifier.size(34.dp)) { Icon(Icons.Default.Remove, null) }
    Text("$q", fontWeight = FontWeight.Bold)
    FilledTonalIconButton({ onChange(q + 1) }, Modifier.size(34.dp)) { Icon(Icons.Default.Add, null) }
}

@Composable
fun ProductCard(p: Product, owner: Boolean, qty: Int, onQty: (Int) -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val c = MaterialTheme.colorScheme
    ElevatedCard(shape = RoundedCornerShape(20.dp), colors = CardDefaults.elevatedCardColors(containerColor = c.surface)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.25f).background(c.surfaceVariant)) {
            if (p.imageUrl.isNotEmpty()) AsyncImage(p.imageUrl, p.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(Icons.Default.Build, null, Modifier.align(Alignment.Center).size(40.dp), tint = c.outline)
        }
        Column(Modifier.padding(12.dp)) {
            Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
            Text(p.description, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = c.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            when {
                owner -> Row(Modifier.fillMaxWidth(), Arrangement.End) {
                    IconButton(onEdit) { Icon(Icons.Default.Edit, "Edit") }
                    IconButton(onDelete) { Icon(Icons.Default.Delete, "Delete", tint = c.error) }
                }
                qty == 0 -> FilledTonalButton({ onQty(1) }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Add to list")
                }
                else -> Box(Modifier.fillMaxWidth(), Alignment.Center) { Stepper(qty, onQty) }
            }
        }
    }
}

@Composable
fun ProductDialog(p: Product, vm: AppVM, onClose: () -> Unit) {
    var name by remember { mutableStateOf(p.name) }
    var desc by remember { mutableStateOf(p.description) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    val busy by vm.busy.collectAsStateWithLifecycle()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri = it ?: uri }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text(if (p.id.isEmpty()) "Add product" else "Edit product") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant).clickable { pick.launch(ImageOnly) }, Alignment.Center) {
                    val model: Any? = uri ?: p.imageUrl.ifEmpty { null }
                    if (model != null) AsyncImage(model, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.AddAPhoto, null); Text("Tap to add photo") }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Product name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(desc, { desc = it }, label = { Text("One-line description") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button({ vm.saveProduct(p.copy(name = name.trim(), description = desc.trim()), uri, onClose) }, enabled = !busy && name.isNotBlank()) {
                Text(if (busy) "Saving…" else "Save")
            }
        },
        dismissButton = { TextButton(onClose, enabled = !busy) { Text("Cancel") } }
    )
}

/* ------------------------------ Cart ------------------------------ */

@Composable
fun CartScreen(vm: AppVM) {
    val products by vm.products.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var note by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf<Uri?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { photo = it ?: photo }
    val lines = vm.cart.entries.mapNotNull { e -> products.find { it.id == e.key }?.let { it to e.value } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Your list", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("No payment here. Book your list, we'll notify you when it's ready, then collect it at the shop.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (lines.isEmpty()) item { Text("No items added yet. You can also attach a photo of your handwritten list below.", style = MaterialTheme.typography.bodyMedium) }
        items(lines, key = { it.first.id }) { (p, q) ->
            ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                        if (p.imageUrl.isNotEmpty()) AsyncImage(p.imageUrl, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Stepper(q) { vm.setQty(p.id, it) }
                }
            }
        }
        item { OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") }, modifier = Modifier.fillMaxWidth(), minLines = 2) }
        item {
            if (photo == null) OutlinedButton({ pick.launch(ImageOnly) }, Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text("Attach photo of your list")
            } else Box {
                AsyncImage(photo, null, Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.Crop)
                FilledTonalIconButton({ photo = null }, Modifier.align(Alignment.TopEnd).padding(8.dp)) { Icon(Icons.Default.Close, null) }
            }
        }
        item {
            Button({ vm.placeOrder(lines.map { OrderItem(it.first.id, it.first.name, it.second) }, note.trim(), photo) { photo = null; note = "" } },
                enabled = !busy && (lines.isNotEmpty() || photo != null), modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text(if (busy) "Booking…" else "Book order", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

/* ------------------------------ Orders ------------------------------ */

@Composable
fun StatusChip(s: String) {
    val (bg, label) = when (s) {
        "READY" -> Color(0xFFCDEFD3) to "Ready to collect"
        "COLLECTED" -> Color(0xFFE0E3EA) to "Collected"
        else -> Color(0xFFFFE8B3) to "Waiting"
    }
    Surface(shape = CircleShape, color = bg) { Text(label, Modifier.padding(10.dp, 4.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFF222222), fontWeight = FontWeight.SemiBold) }
}

@Composable
fun OrdersScreen(vm: AppVM, owner: Boolean) {
    val orders by vm.orders.collectAsStateWithLifecycle()
    var open by remember { mutableStateOf<String?>(null) }
    if (orders.isEmpty()) Empty(if (owner) "No orders yet." else "You haven't booked any orders yet.")
    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(orders, key = { it.id }) { o ->
            ElevatedCard({ open = o.id }, shape = RoundedCornerShape(20.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (owner) o.customerName else "Order #${o.id.take(5).uppercase()}", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        Text("${fmt(o.createdAt)} · ${o.items.size} item(s)${if (o.photoUrl.isNotEmpty()) " · photo" else ""}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusChip(o.status)
                }
            }
        }
    }
    orders.find { it.id == open }?.let { OrderDialog(it, owner, vm) { open = null } }
}

@Composable
fun OrderDialog(o: Order, owner: Boolean, vm: AppVM, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Column { Text(if (owner) o.customerName else "Order #${o.id.take(5).uppercase()}"); Spacer(Modifier.height(6.dp)); StatusChip(o.status) } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (owner) Text("Phone: ${o.phone}", fontWeight = FontWeight.Medium)
                Text("Booked ${fmt(o.createdAt)}", style = MaterialTheme.typography.bodySmall)
                if (!owner && o.status == "READY") Text("Your order is ready. Please collect it at the shop.", color = Color(0xFF1E7B34), fontWeight = FontWeight.SemiBold)
                if (o.items.isNotEmpty()) { HorizontalDivider(); o.items.forEach { Text("• ${it.name}  ×${it.qty}") } }
                if (o.note.isNotBlank()) { HorizontalDivider(); Text("Note: ${o.note}") }
                if (o.photoUrl.isNotEmpty()) { HorizontalDivider(); Text("List photo"); AsyncImage(o.photoUrl, null, Modifier.fillMaxWidth().heightIn(max = 360.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit) }
            }
        },
        confirmButton = {
            when {
                owner && o.status == "PENDING" -> Button({ vm.setStatus(o.id, "READY"); onClose() }) {
                    Icon(Icons.Default.NotificationsActive, null); Spacer(Modifier.width(8.dp)); Text("Ready – notify")
                }
                owner && o.status == "READY" -> Button({ vm.setStatus(o.id, "COLLECTED"); onClose() }) { Text("Mark collected") }
                else -> TextButton(onClose) { Text("Close") }
            }
        },
        dismissButton = { if (owner && o.status != "COLLECTED") TextButton(onClose) { Text("Close") } }
    )
}

/* ---------------------------- Customers ---------------------------- */

@Composable
fun CustomersScreen(vm: AppVM) {
    val list by vm.customers.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<AppUser?>(null) }
    Box(Modifier.fillMaxSize()) {
        if (list.isEmpty()) Empty("No customers yet. Tap “New customer” to create a login.")
        else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.uid }) { c ->
                ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(44.dp)) {
                            Box(contentAlignment = Alignment.Center) { Text(c.name.take(1).uppercase(), fontWeight = FontWeight.Bold) }
                        }
                        Column(Modifier.weight(1f)) { Text(c.name, fontWeight = FontWeight.SemiBold); Text(c.phone, style = MaterialTheme.typography.bodySmall) }
                        IconButton({ deleting = c }) { Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        ExtendedFloatingActionButton({ adding = true }, Modifier.align(Alignment.BottomEnd).padding(20.dp),
            icon = { Icon(Icons.Default.PersonAdd, null) }, text = { Text("New customer") })
    }
    if (adding) {
        var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { if (!busy) adding = false }, title = { Text("New customer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(phone, { phone = it.filter(Char::isDigit) }, label = { Text("Phone (login ID)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                    OutlinedTextField(pw, { pw = it }, label = { Text("Password (min 6)") }, singleLine = true)
                }
            },
            confirmButton = { Button({ vm.createCustomer(name.trim(), phone, pw) { adding = false } }, enabled = !busy && name.isNotBlank() && phone.length >= 10 && pw.length >= 6) { Text(if (busy) "Creating…" else "Create") } },
            dismissButton = { TextButton({ adding = false }, enabled = !busy) { Text("Cancel") } })
    }
    deleting?.let { c ->
        AlertDialog(onDismissRequest = { deleting = null }, title = { Text("Remove ${c.name}?") },
            text = { Text("They will no longer be able to use the app.") },
            confirmButton = { TextButton({ vm.deleteCustomer(c.uid); deleting = null }) { Text("Remove", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } })
    }
}
