package com.asiantraders.shop

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class AppVM(app: Application) : AndroidViewModel(app) {
    val user = MutableStateFlow<AppUser?>(null)
    val ready = MutableStateFlow(false)
    val products = MutableStateFlow<List<Product>>(emptyList())
    val orders = MutableStateFlow<List<Order>>(emptyList())
    val customers = MutableStateFlow<List<AppUser>>(emptyList())
    val busy = MutableStateFlow(false)
    val toast = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val cart = mutableStateMapOf<String, Int>()
    private var jobs = emptyList<Job>()
    private val ctx get() = getApplication<Application>()

    init {
        viewModelScope.launch {
            val p = try { Repo.profile() } catch (e: Exception) { null }
            if (p != null) begin(p)
            ready.value = true
        }
    }

    private fun say(m: String) { toast.tryEmit(m) }

    private fun begin(p: AppUser) {
        jobs.forEach { it.cancel() }
        user.value = p
        jobs = buildList {
            add(viewModelScope.launch { Repo.products().collect { products.value = it } })
            add(viewModelScope.launch { Repo.orders(p).collect { orders.value = it } })
            if (p.isOwner) add(viewModelScope.launch { Repo.customers().collect { customers.value = it } })
        }
        viewModelScope.launch { runCatching { Repo.registerToken(p) } }
    }

    private fun work(ok: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy.value = true
            try { block(); ok?.let { say(it) } } catch (e: Exception) { say(e.message ?: "Something went wrong") }
            busy.value = false
        }
    }

    fun login(id: String, pw: String) {
        viewModelScope.launch {
            busy.value = true
            try {
                Repo.login(id, pw)
                val p = Repo.profile()
                if (p == null) { Repo.logout(); say("Account not found. Please contact the shop.") } else begin(p)
            } catch (e: Exception) { say("Login failed. Check phone number and password.") }
            busy.value = false
        }
    }

    fun logout() {
        jobs.forEach { it.cancel() }; Repo.logout()
        user.value = null; cart.clear(); orders.value = emptyList(); customers.value = emptyList()
    }

    fun setQty(id: String, q: Int) { if (q <= 0) cart.remove(id) else cart[id] = q }

    fun saveProduct(p: Product, img: Uri?, done: () -> Unit) = work("Product saved") { Repo.saveProduct(ctx, p, img); done() }
    fun deleteProduct(p: Product) = work("Product deleted") { Repo.deleteProduct(p) }
    fun createCustomer(name: String, phone: String, pw: String, done: () -> Unit) = work("Customer created") {
        require(pw.length >= 6) { "Password must be at least 6 characters" }
        Repo.createCustomer(ctx, name, phone, pw); done()
    }
    fun deleteCustomer(uid: String) = work("Customer removed") { Repo.deleteCustomer(uid) }

    fun placeOrder(items: List<OrderItem>, note: String, photo: Uri?, done: () -> Unit) = work("Order booked! We'll notify you when it's ready.") {
        Repo.placeOrder(ctx, user.value!!, items, note, photo); cart.clear(); done()
    }
    fun setStatus(id: String, s: String) = work(if (s == "READY") "Customer notified" else null) { Repo.setStatus(id, s) }
}
