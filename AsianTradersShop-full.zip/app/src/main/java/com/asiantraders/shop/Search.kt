package com.asiantraders.shop

/** Order-independent, format-tolerant search: "ss 19x6" finds "19 x 6 SS Pipe". */
object Search {
    private val split = Regex("(?<=\\d)(?=[a-z])|(?<=[a-z])(?=\\d)")
    private val junk = Regex("[^a-z0-9\\u0900-\\u097F\\u0A80-\\u0AFF]+")

    fun tokens(s: String): List<String> =
        s.lowercase().replace('×', 'x').replace(split, " ").split(junk).filter { it.isNotBlank() }

    fun matches(p: Product, query: String): Boolean {
        val q = tokens(query)
        if (q.isEmpty()) return true
        val pt = tokens(p.name + " " + p.description)
        return q.all { t -> pt.any { it.startsWith(t) || (t.length > 2 && it.contains(t)) } }
    }
}
