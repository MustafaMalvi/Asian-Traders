package com.asiantraders.shop

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color(0xFF1B3A6B), onPrimary = Color.White, primaryContainer = Color(0xFFD9E4FA),
    secondary = Color(0xFFF59E0B), onSecondary = Color.Black, secondaryContainer = Color(0xFFFFEFCF),
    background = Color(0xFFF5F6FA), surface = Color.White, surfaceVariant = Color(0xFFE9ECF3),
    onSurfaceVariant = Color(0xFF5B6475), outline = Color(0xFF9AA3B5)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF9DB8EE), onPrimary = Color(0xFF0B1F3F), primaryContainer = Color(0xFF24457A),
    secondary = Color(0xFFFFC04D), background = Color(0xFF0F1219), surface = Color(0xFF181C25),
    surfaceVariant = Color(0xFF262B37), onSurfaceVariant = Color(0xFFB4BBCB)
)

@Composable
fun ShopTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = if (isSystemInDarkTheme()) Dark else Light,
    typography = Typography(),
    shapes = Shapes(medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)),
    content = content
)
