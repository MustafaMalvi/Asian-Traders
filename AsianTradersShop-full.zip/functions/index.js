const admin = require("firebase-admin");
const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
admin.initializeApp();
const android = { priority: "high", notification: { channelId: "orders" } };

// Owner gets a push when a customer books an order.
exports.onOrderCreated = onDocumentCreated("orders/{id}", async (e) => {
  const o = e.data.data();
  await admin.messaging().send({
    topic: "owner",
    notification: { title: "New order", body: `${o.customerName} booked ${o.items.length} item(s)${o.photoUrl ? " + list photo" : ""}` },
    android,
  });
});

// Customer gets a push when the owner marks the order READY.
exports.onOrderReady = onDocumentUpdated("orders/{id}", async (e) => {
  const b = e.data.before.data(), a = e.data.after.data();
  if (b.status === a.status || a.status !== "READY") return;
  const u = await admin.firestore().doc(`users/${a.customerId}`).get();
  const token = u.get("fcmToken");
  if (!token) return;
  await admin.messaging().send({
    token,
    notification: { title: "Your order is ready ✅", body: "Please come to Asian Traders to collect your items." },
    android,
  });
});
