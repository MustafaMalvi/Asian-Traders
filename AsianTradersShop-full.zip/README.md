# Asian Traders Shop (Android, Kotlin + Jetpack Compose + Firebase)

## One-time setup
1. Firebase console → create project → add Android app, package `com.asiantraders.shop`.
   Download `google-services.json` into `app/`.
2. Enable: Authentication (Email/Password), Firestore, Storage, Cloud Messaging.
3. Create the OWNER:
   - Authentication → Add user (e.g. owner@asiantraders.shop + password) → copy its UID.
   - Firestore → collection `users` → document id = that UID → fields:
     `name` (string) "Owner", `phone` (string) "", `role` (string) "owner", `fcmToken` (string) "".
4. Paste `firestore.rules` and `storage.rules` into the console Rules tabs.
5. Notifications (needs Blaze plan): `npm i -g firebase-tools`, `firebase login`,
   `firebase init functions` (use existing `functions/`), then `firebase deploy --only functions`.
6. Open the folder in Android Studio, Sync, Run.

## Using it
- Owner logs in with the owner email + password → Products / Orders / Customers tabs.
- Owner creates customers (name, phone, password). Customers log in with phone + password.
- Customer adds products to "My List" (and/or attaches a list photo) → Book order.
- Owner opens an order → "Ready – notify" → customer gets a push + in-app status.
